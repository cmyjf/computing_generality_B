n = int(input())
tele = []
for x in range(n):
    i = input()
    num = []
    for y in range(len(i)):
        o = ord(i[y])
        if 65 <= o <= 82:
            o = int((o - 65) / 3 + 2)
            num.append(o)
        elif o >= 83:
            o = int((o - 66) / 3 + 2)
            num.append(o)
        elif 48 <= o <= 57:
            o = int(i[y])
            num.append(o)
    tele.append(num)
tele.sort()
judge = 0
while len(tele) != 0:
    a = tele[0]
    l =len(tele)
    dup = 0
    for x in range(l):
        if tele[x] == a:
            dup += 1
    if dup >= 2:
        judge = 1
        print(str(a[0])+str(a[1])+str(a[2])+'-'+str(a[3])+str(a[4])+str(a[5])+str(a[6]),dup)
        dup = 0
    while tele.count(a) != 0:
        tele.remove(a)
        l = len(tele)
if judge == 0:
    print('No duplicates.')
